package rest_api;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.deploy.net.HttpResponse;
import model.BidderValue;
import model.GovernmentAuction;
import model.HighestBidValues;
import okhttp3.*;

import java.io.IOException;
import java.security.GuardedObject;
import java.sql.Timestamp;
import java.util.*;

public class RestfulOperation {


    private String getNewAssetId()
    {
        ArrayList<GovernmentAuction> governmentAuctions = getAuctionGovernment();
        int highestValue =0;

        for(GovernmentAuction governmentAuction: governmentAuctions)
        {
            int thisAssertId = Integer.parseInt(governmentAuction.getAssetId());
            highestValue = highestValue<thisAssertId?thisAssertId:highestValue;
        }

        int newId = highestValue + 1;
        return Integer.toString(newId);
    }

    private String getBidderValueParticipantId()
    {
        int highestValue = 0;
        ArrayList<BidderValue> bidderValues = new ArrayList<BidderValue>();
        String fetchString = "";
        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder()
                .url("http://bfica.eastus.cloudapp.azure.com:3000/api/org.example.basic.SampleParticipant")
                .get()
                .addHeader("Accept", "*/*")
                .addHeader("Cache-Control", "no-cache")
                .addHeader("Host", "bfica.eastus.cloudapp.azure.com:3000")
                .addHeader("Connection", "keep-alive")
                .build();

        Response response = null;

        try {
            response = client.newCall(request).execute();
            fetchString = response.body().string();
            String toReplace = "\"\\$class\":\"org\\.example\\.basic\\.SampleParticipant\",";
            fetchString = fetchString.replaceAll(toReplace, " ");
            System.out.println(fetchString);

            ObjectMapper objectMapper = new ObjectMapper();
            bidderValues = objectMapper.readValue(fetchString, new TypeReference<ArrayList<BidderValue>>(){});

        } catch (IOException e) {
            e.printStackTrace();
        }



        for (BidderValue bidderValueEach:bidderValues) {
            int thisParticipantId = Integer.parseInt(bidderValueEach.getParticipantId());
            highestValue = highestValue<thisParticipantId?thisParticipantId:highestValue;
        }

        int newId = highestValue + 1;
        return Integer.toString(newId);
    }

    public ArrayList<GovernmentAuction> getAuctionGovernment() {
        String fetchString = "";
        ArrayList<GovernmentAuction> governmentAuctions = null;

        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder()
                .url("http://bfica.eastus.cloudapp.azure.com:3000/api/org.example.basic.SampleAsset")
                .get()
                .addHeader("cache-control", "no-cache")
                .build();



        try {
            Response response = client.newCall(request).execute();
            fetchString = response.body().string();
            String toReplace = "\"\\$class\":\"org\\.example\\.basic\\.SampleAsset\",";
            fetchString = fetchString.replaceAll(toReplace, " ");
            System.out.println(fetchString);
            ObjectMapper objectMapper = new ObjectMapper();
            governmentAuctions = objectMapper.readValue(fetchString, new TypeReference<ArrayList<GovernmentAuction>>(){});

            System.out.println(governmentAuctions.get(0).getAssetId());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return governmentAuctions;
    }

    public boolean postAuctionGovernment(GovernmentAuction governmentAuction)
    {
        if(governmentAuction!=null) {
            OkHttpClient client = new OkHttpClient();

            MediaType mediaType = MediaType.parse("application/json");
            String toPost = "{\n  \"$class\": \"org.example.basic.SampleAsset\",\n  \"assetId\": \"" + getNewAssetId() + "\",\n  \"comment\": \"" + governmentAuction.getComment() + "\",\n  \"dateTime\": \"" + governmentAuction.getDateTime() + "\",\n  \"signature\": \"" + governmentAuction.getSignature() + "\"\n}";

            RequestBody body = RequestBody.create(mediaType, toPost );
            Request request = new Request.Builder()
                    .url("http://bfica.eastus.cloudapp.azure.com:3000/api/org.example.basic.SampleAsset")
                    .post(body)
                    .addHeader("Content-Type", "application/json")
                    .addHeader("User-Agent", "PostmanRuntime/7.11.0")
                    .addHeader("Accept", "*/*")
                    .addHeader("Cache-Control", "no-cache")
                    .addHeader("Host", "bfica.eastus.cloudapp.azure.com:3000")
                    .addHeader("accept-encoding", "gzip, deflate")
                    .addHeader("content-length", "178")
                    .addHeader("Connection", "keep-alive")
                    .addHeader("cache-control", "no-cache")
                    .build();

            try {
                Response response = client.newCall(request).execute();
                return true;
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return false;
    }

    public ArrayList<BidderValue> getAuctionBidderValue()
    {
        ArrayList<BidderValue> bidderValues = new ArrayList<BidderValue>();
        ArrayList<BidderValue> allBidderValues = null;
        String fetchString = "";
        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder()
                .url("http://bfica.eastus.cloudapp.azure.com:3000/api/org.example.basic.SampleParticipant")
                .get()
                .addHeader("Accept", "*/*")
                .addHeader("Cache-Control", "no-cache")
                .addHeader("Host", "bfica.eastus.cloudapp.azure.com:3000")
                .addHeader("Connection", "keep-alive")
                .build();

        Response response = null;

        try {
            response = client.newCall(request).execute();
            fetchString = response.body().string();
            String toReplace = "\"\\$class\":\"org\\.example\\.basic\\.SampleParticipant\",";
            fetchString = fetchString.replaceAll(toReplace, " ");
            System.out.println(fetchString);

            ObjectMapper objectMapper = new ObjectMapper();
            allBidderValues = objectMapper.readValue(fetchString, new TypeReference<ArrayList<BidderValue>>(){});

        } catch (IOException e) {
            e.printStackTrace();
        }


        for(BidderValue bidderValueEach : allBidderValues)
        {
            if(!(bidderValueEach.getComment().equals("winning") || bidderValueEach.getBidValue().equals("null")))
            {
                bidderValues.add(bidderValueEach);
            }
        }

        return bidderValues;
    }

    public boolean postBidValues(BidderValue bidderValue)
    {
        OkHttpClient client = new OkHttpClient();

        MediaType mediaType = MediaType.parse("application/json");
        String toPost = "{\n  \"$class\": \"org.example.basic.SampleParticipant\",\n  \"participantId\": \""+getBidderValueParticipantId()+"\",\n  \"auctionId\": \""+bidderValue.getAuctionId()+"\",\n  \"bidValue\": \""+bidderValue.getBidValue()+"\",\n  \"comment\": \""+bidderValue.getComment()+"\",\n  \"dateTime\": \""+bidderValue.getDateTime()+"\",\n  \"signature\": \""+bidderValue.getSignature()+"\"\n}";
        RequestBody body = RequestBody.create(mediaType, toPost);
        Request request = new Request.Builder()
                .url("http://bfica.eastus.cloudapp.azure.com:3000/api/org.example.basic.SampleParticipant")
                .post(body)
                .addHeader("Content-Type", "application/json")
                .addHeader("cache-control", "no-cache")
                .build();



        try {
            Response response = client.newCall(request).execute();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }


    public ArrayList<BidderValue> getAuctionPublic()
    {
        ArrayList<BidderValue> bidderValues = new ArrayList<BidderValue>();
        ArrayList<BidderValue> allBidderValues = null;
        String fetchString = "";
        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder()
                .url("http://bfica.eastus.cloudapp.azure.com:3000/api/org.example.basic.SampleParticipant")
                .get()
                .addHeader("Accept", "*/*")
                .addHeader("Cache-Control", "no-cache")
                .addHeader("Host", "bfica.eastus.cloudapp.azure.com:3000")
                .addHeader("Connection", "keep-alive")
                .build();

        Response response = null;

        try {
            response = client.newCall(request).execute();
            fetchString = response.body().string();
            String toReplace = "\"\\$class\":\"org\\.example\\.basic\\.SampleParticipant\",";
            fetchString = fetchString.replaceAll(toReplace, " ");
            System.out.println(fetchString);

            ObjectMapper objectMapper = new ObjectMapper();
            allBidderValues = objectMapper.readValue(fetchString, new TypeReference<ArrayList<BidderValue>>(){});

        } catch (IOException e) {
            e.printStackTrace();
        }


        for(BidderValue bidderValueEach : allBidderValues)
        {
            if((bidderValueEach.getComment().equals("winning") && !bidderValueEach.getBidValue().equals("null")))
            {
                bidderValues.add(bidderValueEach);
            }
        }

        return bidderValues;
    }


    public boolean postAuctionPublic(HighestBidValues highestBidValues)
    {
        OkHttpClient client = new OkHttpClient();

        MediaType mediaType = MediaType.parse("application/json");
        String toPost = "{\n  \"$class\": \"org.example.basic.SampleTransaction\",\n  \"participantId\": \""+highestBidValues.getParticipantId()+"\",\n  \"auctionId\": \""+highestBidValues.getAuctionId()+"\",\n  \"highestBid\": \""+highestBidValues.getHighestBid()+"\",\n  \"comment\": \""+highestBidValues.getComment()+"\",\n  \"signature\": \""+highestBidValues.getSignature()+"\",\n  \"timestamp\": \"2019-05-08T19:16:31.773Z\"\n}";


        RequestBody body = RequestBody.create(mediaType, toPost);
        Request request = new Request.Builder()
                .url("http://bfica.eastus.cloudapp.azure.com:3000/api/org.example.basic.SampleTransaction")
                .post(body)
                .addHeader("Content-Type", "application/json")
                .addHeader("cache-control", "no-cache")
                .build();

        try {
            Response response = client.newCall(request).execute();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean isAuctionIdInWinning(String auctionID)
    {
        boolean check = false;

        ArrayList<BidderValue> allWinningBidderValues = getAuctionPublic();
        for(BidderValue eachWinningBidderValue : allWinningBidderValues)
        {
            if(eachWinningBidderValue.getAuctionId().equals(auctionID))
            {
                check = true;
            }
        }
        return check;
    }


    public static void main(String [] args)
    {
        RestfulOperation restfulOperation = new RestfulOperation();
        BidderValue bidderValue = new BidderValue("1", "1", "5001", "will Obey", "sadfas1313asfsd/?fsdafas", "2019/05/09 01:45:12");
//        restfulOperation.postBidValues(bidderValue);
//        restfulOperation.postBidValues(bidderValue);
//        System.out.println(restfulOperation.getNewAssetId());
        System.out.println(restfulOperation.getBidderValueParticipantId());

    }
}