package miscellaneous;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TimeFunction {

    public String getCurrentTime()
    {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd hh:mm:ss");
        Date date = new Date(System.currentTimeMillis());
        return formatter.format(date);
    }

    public int dateCompare(String date1, String date2)
    {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd hh:mm:ss");
        try {
            Date tempDate1 = formatter.parse(date1);
            Date tempDate2 = formatter.parse(date2);
            return tempDate1.compareTo(tempDate2);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public String dateToString(Date date)
    {
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd hh:mm:ss");
        return format.format(date);
    }

    public int dateTimeCompareWithCurrentTimePreference(String date)
    {
        return dateCompare(getCurrentTime(), date);
    }

    public static void main(String [] args)
    {
        TimeFunction timeFunction = new TimeFunction();
        int audit = timeFunction.dateCompare(timeFunction.getCurrentTime(), "2019/05/08 06:17:42");
        System.out.println(audit);
    }
}