package manageBean;


import miscellaneous.TimeFunction;
import model.BidderValue;
import model.GovernmentAuction;
import rest_api.RestfulOperation;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

@ManagedBean(name="bidder_auction_placement")
@SessionScoped
public class BidderAuctionPlacement {

    String placementId;
    String bidderValue;
    String signature;
    Date time;
    String hash;
    String comment;
    String governmentId;

    ArrayList<GovernmentAuction> governmentAuctions;
    GovernmentAuction governmentAuction;

    public BidderAuctionPlacement() {
        RestfulOperation restfulOperation = new RestfulOperation();
        TimeFunction timeFunction = new TimeFunction();

        governmentAuctions = new ArrayList<GovernmentAuction>();

        ArrayList<GovernmentAuction> tempList = restfulOperation.getAuctionGovernment();
        for(GovernmentAuction governmentAuctionEach : tempList)
        {

            if(timeFunction.dateTimeCompareWithCurrentTimePreference(governmentAuctionEach.getDateTime())<0)
            {
                governmentAuctions.add(governmentAuctionEach);
            }
            else
            {
                System.out.println(governmentAuctionEach.getDateTime());
            }
        }
        time = new Date(System.currentTimeMillis());
        governmentAuction = new GovernmentAuction();
    }

    public void init()
    {
        RestfulOperation restfulOperation = new RestfulOperation();
        TimeFunction timeFunction = new TimeFunction();

        governmentAuctions.clear();
        ArrayList<GovernmentAuction> tempList = restfulOperation.getAuctionGovernment();
        for(GovernmentAuction governmentAuctionEach : tempList)
        {

            if(timeFunction.dateTimeCompareWithCurrentTimePreference(governmentAuctionEach.getDateTime())<0)
            {
                governmentAuctions.add(governmentAuctionEach);
            }
            else
            {
                System.out.println(governmentAuctionEach.getDateTime());
            }
        }

    }

    public String selectAuction()
    {
        if(governmentAuction != null && !governmentAuction.getComment().equals(""))
        {
            return "selectedBidValue.xhtml";
        }

        return "selectedBidValue.xhtml";
    }

    public String submitBidValue()
    {
        FacesMessage msg;
        msg = new FacesMessage("Submit Bid Value:" + bidderValue +"\nComment: " + comment);
        FacesContext.getCurrentInstance().addMessage(null, msg);

        RestfulOperation restfulOperation = new RestfulOperation();
        BidderValue bidderValueObject = new BidderValue(governmentAuction.getAssetId(), "1", bidderValue, comment, "sadfas1313asfsd/?fsdafas", getCurrentTime());

        if(restfulOperation.postBidValues(bidderValueObject))
        {
            return "/ResponsePage/responseSuccessfulOperation.xhtml";
        }

        return "";
    }

    public String getCurrentTime()
    {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd hh:mm:ss");
        Date date = new Date(System.currentTimeMillis());
        return formatter.format(date);
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getPlacementId() {
        return placementId;
    }

    public void setPlacementId(String placementId) {
        this.placementId = placementId;
    }

    public String getBidderValue() {
        return bidderValue;
    }

    public void setBidderValue(String bidderValue) {
        this.bidderValue = bidderValue;
    }

    public ArrayList<GovernmentAuction> getGovernmentAuctions() {
        init();
        return governmentAuctions;
    }

    public void setGovernmentAuctions(ArrayList<GovernmentAuction> governmentAuctions) {
        this.governmentAuctions = governmentAuctions;
    }

    public GovernmentAuction getGovernmentAuction() {
        return governmentAuction;
    }

    public void setGovernmentAuction(GovernmentAuction governmentAuction) {
        this.governmentAuction = governmentAuction;
    }

    public String getGovernmentId() {
        return governmentId;
    }

    public void setGovernmentId(String governmentId) {
        this.governmentId = governmentId;
    }
}