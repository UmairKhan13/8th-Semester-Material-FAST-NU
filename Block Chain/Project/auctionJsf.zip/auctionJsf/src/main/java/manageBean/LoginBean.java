package manageBean;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import java.io.Serializable;

@ManagedBean(name="loginBean")
@SessionScoped
public class LoginBean implements Serializable {

    String ID;
    String password;

    public String isGovernment()
    {
        if(ID.equals("government") && password.equals("password"))
        {
            return "governmentHome.xhtml";
        }
        else
        {
            FacesMessage msg;

            msg = new FacesMessage("Incorrect user ID and Password Matching");

            FacesContext.getCurrentInstance().addMessage(null, msg);
        }


        return "";
    }

    public String isBidder()
    {
        boolean isValid = false;
        for(int i =0; i<10; i++) {
            String hardcodedId = "bidder" + i;
            String hardcodedPassword = "user" + i;
            if (ID.equals(hardcodedId) && password.equals(hardcodedPassword)) {
                isValid = true;
                return "bidderHome.xhtml";
            }
        }
        if(!isValid)
        {
            FacesMessage msg;

            msg = new FacesMessage("Incorrect user ID and Password Matching");

            FacesContext.getCurrentInstance().addMessage(null, msg);
        }

        return "";
    }



    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}