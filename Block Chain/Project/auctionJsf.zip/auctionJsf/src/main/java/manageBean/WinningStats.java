package manageBean;


import model.BidderValue;
import rest_api.RestfulOperation;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import java.util.ArrayList;

@ManagedBean(name="winningStats")
@SessionScoped
public class WinningStats {

    ArrayList<BidderValue> bidderValues;
    public WinningStats()
    {
        RestfulOperation restfulOperation = new RestfulOperation();
        bidderValues = restfulOperation.getAuctionPublic();
    }

    public ArrayList<BidderValue> getBidderValues() {
        return bidderValues;
    }

    public void setBidderValues(ArrayList<BidderValue> bidderValues) {
        this.bidderValues = bidderValues;
    }
}
