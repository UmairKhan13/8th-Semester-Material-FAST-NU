package manageBean;

import javafx.util.converter.LocalDateStringConverter;
import miscellaneous.TimeFunction;
import model.GovernmentAuction;
import rest_api.RestfulOperation;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.bean.ViewScoped;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@ManagedBean(name="auction_create")
@ViewScoped
public class AuctionCreate {

    String comment;
    String dateString;
    public AuctionCreate()
    {
        TimeFunction timeFunction = new TimeFunction();
        dateString = timeFunction.getCurrentTime();
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getDateString() {
        return dateString;
    }

    public void setDateString(String dateString) {
        this.dateString = dateString;
    }

    public void submitAuctionDetails()
    {
        // check more than current time
        RestfulOperation restfulOperation = new RestfulOperation();
        GovernmentAuction governmentAuction = new GovernmentAuction("",comment, "sdf1341asf9080fdfasfd", dateString);
        restfulOperation.postAuctionGovernment(governmentAuction);
/*        System.out.println("Comments: " + comment);
        System.out.println("Date: "  + date);
        System.out.println("Date String"+ dateString);
*/

    }
}
