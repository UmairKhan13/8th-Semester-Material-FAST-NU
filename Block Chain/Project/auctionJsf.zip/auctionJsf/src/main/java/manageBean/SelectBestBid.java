package manageBean;

import miscellaneous.TimeFunction;
import model.BidderValue;
import model.GovernmentAuction;
import model.HighestBidValues;
import rest_api.RestfulOperation;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import java.util.ArrayList;
import java.util.Date;

@ManagedBean(name="select_best_bid")
@SessionScoped
public class SelectBestBid {
    String placementId;
    String bidderValue;
    String time;
    String comment;
    String governmentId;

    ArrayList<GovernmentAuction> governmentAuctions;
    GovernmentAuction governmentAuction;

    ArrayList<BidderValue> bidderValues;
    BidderValue bidderValueOject;

    public SelectBestBid() {
        governmentAuctions = new ArrayList<GovernmentAuction>();
        RestfulOperation restfulOperation = new RestfulOperation();
        TimeFunction timeFunction = new TimeFunction();


        ArrayList<GovernmentAuction> tempGovernmentAuction =restfulOperation.getAuctionGovernment();
        time = timeFunction.getCurrentTime();

        if(tempGovernmentAuction != null) {
            for (GovernmentAuction governmentAuctionEach : tempGovernmentAuction) {
                if (timeFunction.dateTimeCompareWithCurrentTimePreference(governmentAuctionEach.getDateTime()) > 0) {
                    if(!restfulOperation.isAuctionIdInWinning(governmentAuctionEach.getAssetId())) {
                        governmentAuctions.add(governmentAuctionEach);
                    }
                }
            }
        }
        governmentAuction = new GovernmentAuction();
        bidderValues = new ArrayList<BidderValue>();
        bidderValueOject = new BidderValue();


    }

    public String  selectBestValue()
    {
        TimeFunction timeFunction = new TimeFunction();
        RestfulOperation restfulOperation = new RestfulOperation();
        bidderValues.clear();
        ArrayList<BidderValue> allBidderValues = restfulOperation.getAuctionBidderValue();
        for(BidderValue bidderValueObj : allBidderValues)
        {
            if(bidderValueObj.getAuctionId().equals(governmentAuction.getAssetId()) && bidderValueObj.getDateTime().compareTo(timeFunction.getCurrentTime())<0)
            {
                bidderValues.add(bidderValueObj);
            }
        }
        return "selectBestBid.xhtml";
    }

    public String submitBestBid()
    {
        TimeFunction timeFunction = new TimeFunction();
        RestfulOperation restfulOperation = new RestfulOperation();
        BidderValue bidderValueForWinner = new BidderValue(governmentAuction.getAssetId(), "", bidderValueOject.getBidValue(),"winning","sf234ilfasfy274238402iu", timeFunction.getCurrentTime());
        restfulOperation.postBidValues(bidderValueForWinner);
        return "";
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getPlacementId() {
        return placementId;
    }

    public void setPlacementId(String placementId) {
        this.placementId = placementId;
    }

    public String getBidderValue() {
        return bidderValue;
    }

    public void setBidderValue(String bidderValue) {
        this.bidderValue = bidderValue;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getGovernmentId() {
        return governmentId;
    }

    public void setGovernmentId(String governmentId) {
        this.governmentId = governmentId;
    }

    public ArrayList<GovernmentAuction> getGovernmentAuctions() {
                return governmentAuctions;
    }

    public void setGovernmentAuctions(ArrayList<GovernmentAuction> governmentAuctions) {
        this.governmentAuctions = governmentAuctions;
    }

    public ArrayList<BidderValue> getBidderValues() {
        return bidderValues;
    }

    public void setBidderValues(ArrayList<BidderValue> bidderValues) {
        this.bidderValues = bidderValues;
    }

    public BidderValue getBidderValueOject() {
        return bidderValueOject;
    }

    public void setBidderValueOject(BidderValue bidderValueOject) {
        this.bidderValueOject = bidderValueOject;
    }

    public GovernmentAuction getGovernmentAuction() {
        return governmentAuction;
    }

    public void setGovernmentAuction(GovernmentAuction governmentAuction) {
        this.governmentAuction = governmentAuction;
    }
}
