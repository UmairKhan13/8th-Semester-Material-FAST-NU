package model;

public class HighestBidValues {

      String participantId;
      String auctionId;
      String highestBid;
      String comment;
      String signature;
      String transactionId;
      String timestamp;

    public HighestBidValues() {
    }

    public HighestBidValues(String participantId, String auctionId, String highestBid, String comment, String signature, String transactionId, String timestamp) {
        this.participantId = participantId;
        this.auctionId = auctionId;
        this.highestBid = highestBid;
        this.comment = comment;
        this.signature = signature;
        this.transactionId = transactionId;
        this.timestamp = timestamp;
    }

    public String getParticipantId() {
        return participantId;
    }

    public void setParticipantId(String participantId) {
        this.participantId = participantId;
    }

    public String getAuctionId() {
        return auctionId;
    }

    public void setAuctionId(String auctionId) {
        this.auctionId = auctionId;
    }

    public String getHighestBid() {
        return highestBid;
    }

    public void setHighestBid(String highestBid) {
        this.highestBid = highestBid;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }
}
