package model;

public class BidderValue {

    String auctionId;
    String participantId;
    String bidValue;
    String comment;
    String signature;
    String dateTime;

    public BidderValue() {
    }

    public BidderValue(String auctionId, String participantId, String bidValue, String comment, String signature, String dateTime) {
        this.auctionId = auctionId;
        this.participantId = participantId;
        this.bidValue = bidValue;
        this.comment = comment;
        this.signature = signature;
        this.dateTime = dateTime;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getAuctionId() {
        return auctionId;
    }

    public void setAuctionId(String auctionId) {
        this.auctionId = auctionId;
    }

    public String getParticipantId() {
        return participantId;
    }

    public void setParticipantId(String participantId) {
        this.participantId = participantId;
    }

    public String getBidValue() {
        return bidValue;
    }

    public void setBidValue(String bidValue) {
        this.bidValue = bidValue;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public String getDateTime() {
        return dateTime;
    }

    public void setDateTime(String dateTime) {
        this.dateTime = dateTime;
    }
}
