package model;

import java.util.Date;

public class GovernmentAuction {

    String assetId;
    String comment;
    String signature;
    String dateTime;

    public GovernmentAuction() {
    }

    public GovernmentAuction(String assetId, String comment, String signature, String dateTime) {
        this.assetId = assetId;
        this.comment = comment;
        this.signature = signature;
        this.dateTime = dateTime;
    }

    public String getAssetId() {
        return assetId;
    }

    public void setAssetId(String assetId) {
        this.assetId = assetId;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public String getDateTime() {
        return dateTime;
    }

    public void setDateTime(String dateTime) {
        this.dateTime = dateTime;
    }
}